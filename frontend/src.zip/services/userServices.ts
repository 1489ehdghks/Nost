export const fetchUserData = async (userId: string) => {
    try {
        const response = await fetch(`https://your-api-endpoint.com/users/${userId}`);
        if (!response.ok) {
            throw new Error('Failed to fetch user data');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error fetching user data:", error);
        throw error;
    }
};
