// src/services/authService.ts
export const login = async (username: string, password: string): Promise<boolean> => {
    // 여기에 백엔드 로그인 API 호출 코드 구현
    // 예제로는 간단히 항상 true를 반환하는 가짜 로직을 사용
    return true;
};
