import { UserState } from './types';

// 사용자 관련 슬라이스의 초기 상태 정의
export const userInitialState: UserState = {
    data: null,
    loading: false,
    error: null,
};