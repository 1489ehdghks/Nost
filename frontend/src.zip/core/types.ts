export interface UserData {
    id: number;
    name: string;
    email: string;
}


export interface UserState {
    data: UserData | null;
    loading: boolean;
    error: string | null;
}
