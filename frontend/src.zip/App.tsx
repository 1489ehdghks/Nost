import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import './App.scss';
import AppRoutes from './core/AppRoutes';
import Navbar from './components/Navbar';

const App: React.FC = () => {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <AppRoutes />
      </div>
    </Router>
  );
};

export default App;
