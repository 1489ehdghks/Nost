
const HomePage: React.FC = () => {
    return <div>Home Page</div>;
};

export default HomePage;
