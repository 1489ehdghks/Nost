// src/pages/Login/Login.tsx
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { setLoggedIn } from '../slices/authSlice';
import { login } from '../services/authServices';

const LoginPage: React.FC = () => {
    const dispatch = useDispatch();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    const handleLogin = async () => {
        const result = await login(username, password);
        dispatch(setLoggedIn(result));
    };

    return (
        <div>
            <h2>Login</h2>
            <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
            />
            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
            />
            <button onClick={handleLogin}>Login</button>
        </div>
    );
};

export default LoginPage;
