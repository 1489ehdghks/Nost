// src/components/UserProfile.js
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUser } from '../slices/userSlice';
import { RootState, AppDispatch } from '../core/store';


interface UserProfileProps {
    userId: string;
}


const UserProfile: React.FC<UserProfileProps> = ({ userId }) => {
    const dispatch = useDispatch();
    const { data, loading, error } = useSelector((state: RootState) => state.user);

    useEffect(() => {
        dispatch(fetchUser(userId));
    }, [dispatch, userId]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;

    return (
        <div>
            <h1>User Profile</h1>
            {data && <div>{data.name} - {data.email}</div>}
        </div>
    );
};

export default UserProfile;
