// src/features/users/userSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchUserData } from '../services/userServices';
import { UserState } from '../core/types';

export const fetchUser = createAsyncThunk(
    'user/fetchUser',
    async (userId: string, { rejectWithValue }) => {
        try {
            const userData = await fetchUserData(userId);
            return userData;
        } catch (error) {
            // 실패 시 에러 메시지를 반환합니다.
            // error 객체의 구조나 처리 방법은 실제 에러 핸들링 로직에 따라 달라질 수 있습니다.
            return rejectWithValue(error.message);
        }
    }
);

const initialState: UserState = {
    data: null,
    loading: false,
    error: null,
};


const userSlice = createSlice({
    name: 'user',
    initialState,
    reducers: {
    },
    extraReducers: (builder) => {
        builder
            .addCase(fetchUser.pending, (state) => {
                state.loading = true;
            })
            .addCase(fetchUser.fulfilled, (state, action: PayloadAction<any>) => {
                state.loading = false;
                state.data = action.payload;
            })
            .addCase(fetchUser.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload as string;
            });
    },
});

export default userSlice.reducer;
