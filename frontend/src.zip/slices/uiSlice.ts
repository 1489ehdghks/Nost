import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    modal: {
        isShow: false
    }
};

const uiSlice = createSlice({
    name: 'ui',
    initialState,
    reducers: {
        toggleModal: (state) => {
            state.modal.isShow = !state.modal.isShow;
        }
    }
});

export const { toggleModal } = uiSlice.actions;

export default uiSlice.reducer;
